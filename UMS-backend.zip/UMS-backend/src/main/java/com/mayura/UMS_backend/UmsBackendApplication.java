package com.mayura.UMS_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UmsBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(UmsBackendApplication.class, args);
	}

}
