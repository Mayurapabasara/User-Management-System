package com.mayura.UMS_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UmsBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
